import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import * as signalR from '@microsoft/signalr';
import { SignalrService } from './signalr.service';
import { FormsModule, NgModel } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  public messages: string[] = [];
  public user : string = "";
  public message:string = "";
  constructor(private signalRService:SignalrService) {}

  ngOnInit(): void {
    this.signalRService.startConnection().subscribe(() => {
      this.signalRService.receiveMessage().subscribe((message) => {
        this.messages.push(message);
      });
    });
  }

  sendMessage(user:string,message: string): void {
    this.signalRService.sendMessage(user,message);
  }

  

}
